/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cityt;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author rawan
 */
public class DAO {

    List<City> cities = new ArrayList<>();

    public static List<String> readFile(String filePath) {
        
        File file = new File(filePath);
        String line = null;
        List<String> fileLines = new ArrayList<>();

        boolean isStart = true;

        try {
            Scanner reader = new Scanner(file);
            while (reader.hasNextLine()) {
                line = reader.nextLine();
                //System.out.println(line);
                if (isStart) {
                    isStart = false;
                } else {
                    fileLines.add(line);
                }

            }
        } catch (IOException e) {
            System.out.println("error : " + e);
        }

        return fileLines;

    }

    public static List<City> readCities(List<String> lines) {

        List<City> cities = new ArrayList<>();
        for (String line : lines) {

            String[] fields = line.split("\",\"");
            City city = new City();

            city.setCityName(fields[0]);
            city.setCapital(fields[8]);
            city.setCountryName(fields[4]);
            if (fields[9].length() != 0) {
                city.setPopulation(Double.parseDouble(fields[9]));
            }

            city.setIso3(fields[6]);
            cities.add(city);

        }

        return cities;

    }

    public static List<Country> readCountry(List<String> lines) {

        List<Country> countries = new ArrayList<>();
        for (String line : lines) {

            String[] fields = line.split(",");
            Country country = new Country();

            country.setContinent(fields[2]);
            country.setFIFA(fields[0]);
            country.setOfficialName(fields[1]);
            countries.add(country);

        }

        return countries;
        
    }
}

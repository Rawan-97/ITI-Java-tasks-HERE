/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cityt;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author rawan
 */
public class CityT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        String filePath = "///home/rawan/Downloads/cities.csv";
//        
//        List<String> lines = new ArrayList<>();
//        lines = DAO.readFile(filePath);
//        //lines.forEach(l -> System.out.println(l));
//        List<City> y =  DAO.readCities(lines);
//        y.forEach(city -> System.out.println(city));
//        //System.out.println(y);
        
        String countryFilePath = "///home/rawan/Downloads/countries.csv";
        List<Country> c = DAO.readCountry(DAO.readFile(countryFilePath));
        c.forEach(country -> System.out.println(country));
        
       
        
    }
    
}

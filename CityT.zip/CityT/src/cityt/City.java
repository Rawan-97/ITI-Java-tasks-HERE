/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cityt;

/**
 *
 * @author rawan
 */
public class City {

    private String cityName;
    private String countryName;
    private String iso3;
    private String capital;
    private Double population;

    public City() {
    }

    public City(String city, String country, String iso3, String capital, Double population) {
        this.cityName = city;
        this.countryName = country;
        this.iso3 = iso3;
        this.capital = capital;
        this.population = population;
    }

    @Override
    public String toString() {
        return "City{" + "city=" + cityName + ", country=" + countryName + ", iso3=" + iso3 + ", capital=" + capital + ", population=" + population + '}';
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public void setIso3(String iso3) {
        this.iso3 = iso3;
    }

    public void setCapital(String capital) {
        this.capital = capital;
    }

    public void setPopulation(Double population) {
        this.population = population;
    }

    public String getCityName() {
        return cityName;
    }

    public String getCountryName() {
        return countryName;
    }

    public String getIso3() {
        return iso3;
    }

    public String getCapital() {
        return capital;
    }

    public Double getPopulation() {
        return population;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cityt;

/**
 *
 * @author rawan
 */
public class Country {
    private String FIFA;
    private String officialName;
    private String continent;

    public Country() {
    }

    public Country(String FIFA, String officialName, String continent) {
        this.FIFA = FIFA;
        this.officialName = officialName;
        this.continent = continent;
    }

    public String getFIFA() {
        return FIFA;
    }

    public String getOfficialName() {
        return officialName;
    }

    public String getContinent() {
        return continent;
    }

    public void setFIFA(String FIFA) {
        this.FIFA = FIFA;
    }

    public void setOfficialName(String officialName) {
        this.officialName = officialName;
    }

    public void setContinent(String continent) {
        this.continent = continent;
    }

    @Override
    public String toString() {
        return "Country{" + "FIFA=" + FIFA + ", officialName=" + officialName + ", continent=" + continent + '}';
    }
    
    
    
    
}
